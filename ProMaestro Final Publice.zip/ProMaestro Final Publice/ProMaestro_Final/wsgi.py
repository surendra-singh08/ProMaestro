"""WSGI entry point for hosts that expect a module named wsgi."""
from app import app

application = app
