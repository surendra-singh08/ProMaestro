@echo off
cd /d "%~dp0"
py -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
set ALLOW_DEMO_RESET_LINK=true
python app.py
