# ProMaestro — Final Starter Build

A fresh, database-backed project and task management application with an original Jira-inspired workspace UI. It uses Flask, SQLite, Bootstrap 5 and custom CSS. It does **not** copy Jira's logo, brand assets or exact UI.

## Included functionality

- Company registration creates a company workspace and its Company Manager account
- Separate Company Manager, Manager and Employee sign-in options
- Company Manager can create employee and manager accounts; employees cannot self-register
- Secure password hashing, account settings and session handling
- Roles: admin, manager, member and viewer; admin/manager visibility is limited to their own company
- Projects with status, dates, project keys and project membership
- Tasks with assignee, priority, status, deadline, estimate, comments and activity history
- Board view grouped by workflow status, search and filters
- In-app notifications for task assignments and adding project members
- Dashboard metrics calculated from SQLite records (no seeded demo records)
- Reports and CSV export from current database records
- AI assistant page with optional live OpenAI-compatible Chat Completions API configuration; it clearly states when no API key is configured
- Responsive desktop/tablet/mobile UI

## Requirements

- Python 3.10 or newer
- Internet connection for Google Fonts, Bootstrap and Bootstrap Icons CDN (the app still runs without the remote styling assets, but appearance will differ)
- Optional: an API key if you want live AI responses

## Run locally (Windows / VS Code)

1. Extract this ZIP into a new folder, for example `ProMaestro_Final`.
2. Open PowerShell in the extracted `ProMaestro_Final` folder (File Explorer address bar: type `powershell` and press Enter).
3. Create and activate a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal and activate again. Alternatively, use `cmd.exe` and `.venv\Scripts\activate.bat`.

4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Set a secret key for the current PowerShell session:

   ```powershell
   $env:SECRET_KEY = [guid]::NewGuid().ToString() + [guid]::NewGuid().ToString()
   ```

6. Start the app:

   ```powershell
   python app.py
   ```

7. Open `http://127.0.0.1:5000` in your browser and create your account.

The SQLite file `promaestro.db` is created automatically beside `app.py`. The database starts empty. It does not generate fake projects or task activity. Existing database records are preserved when the app initializes. Company data access is scoped by company ID, and employees can access only projects they own or are assigned to.

## Register a company and manage accounts

Open `http://127.0.0.1:5000`, choose Company Registration, and create the company workspace and Company Manager account. After signing in, open **Employees** to create employee or manager accounts. Share the initial password securely; users can change it in Settings. Managers sign in using the Manager option, and employees use Employee Login. Employee self-registration is intentionally disabled so only company-authorized accounts can enter the workspace.

## Enable live AI responses (optional)

The AI assistant uses the OpenAI Chat Completions API when `OPENAI_API_KEY` is set. If the key is absent, it displays a clear setup message rather than pretending to generate AI results.

PowerShell (current terminal only):

```powershell
$env:OPENAI_API_KEY = "YOUR_API_KEY"
$env:OPENAI_MODEL = "gpt-4o-mini"
python app.py
```

Never commit or share your real API key, and do not expose it in browser-side JavaScript. API use may incur charges depending on your provider account and model. You can leave AI unconfigured while developing/testing the core app.

## Database and backups

- `promaestro.db` contains users, projects, tasks, comments, activity and notifications.
- Stop the server before copying the database for a consistent backup.
- Keep backups outside the public web root.
- Do not delete `promaestro.db` after users start creating real records.
- For production, use a persistent disk/database and configure a strong secret key using environment variables.

## Deployment overview

This folder is designed to be deployable independently of the old PythonAnywhere app. Create a **new web app/service** at your chosen host and upload this folder or connect a separate Git repository. Use:

- Install command: `pip install -r requirements.txt`
- WSGI entry point (if required): import `app` from `app.py` and expose `app` as the WSGI application
- Persistent database path: set `PROMAESTRO_DB` to a writable persistent location if your host's app directory is ephemeral
- Environment variables: `SECRET_KEY` (required in production), optional `OPENAI_API_KEY`, optional `OPENAI_MODEL`
- Production server: use the host's WSGI server; do not use Flask's development server as the public production server

Before deploying, test registration, login/logout, project access, task assignment/status changes, comments, CSV export and database persistence on the target host. Free hosting plans can sleep, have storage limitations or change their terms; do not assume that a local SQLite file is persistent unless the host explicitly supports it.

## Known scope / next hardening tasks

This is a functional fresh build, but it still needs a deployment-specific security review before use with sensitive or public production data. In particular, configure a strong secret key, enable HTTPS at the host, add CSRF protection, configure backups, set rate limits for authentication, and validate the exact permissions required by your team. AI suggestions are advisory and are not automatically written into task records.


## Added Intelligence Hub
The current build includes an `/intelligence` workspace page with:
- Project risk indicators calculated from actual task/project due dates and blocked/overdue task counts (rule-based, not predictive AI).
- Team workload comparison based on assigned, completed, and overdue tasks.
- Meeting-note task extraction using local line/sentence parsing, followed by a review-and-confirm step before tasks are saved. This extractor is not an AI model.
- What-if duration calculator based on task count and user-entered team capacity; estimates are illustrative.
- Project knowledge items (notes, decisions, requirements, meeting summaries) stored in SQLite.
- Configurable in-app notification rules for upcoming deadlines, overdue tasks, and blocked tasks. Rule evaluation currently runs when the Intelligence Hub is opened, not as a background scheduler. The “completed” rule type is currently a placeholder and does not trigger notifications yet.
- The supplied ProMaestro logo is used in the main sidebar and authentication branding.


## Product approach: familiar workflow, original ProMaestro features

ProMaestro takes inspiration from common project-management patterns found in Jira, Asana and Trello without copying their branding or exact interface. The current build includes:

- **Project and task workflow:** project spaces, task lists, a status-grouped board, assignees, priorities, deadlines, estimates and comments.
- **Team coordination:** company workspaces, role-based accounts, project membership, notifications and an activity timeline.
- **Management overview:** company-wide delivery metrics, team workload counts, project progress, overdue/blocked task visibility and CSV reports.
- **Intelligence Hub:** rule-based risk signals, workload comparison, meeting-note task suggestions with a confirmation step, project knowledge notes and configurable notification rules.
- **AI assistant:** planning and risk-analysis guidance; live LLM replies require an API key. Without a key, the app clearly uses a local rule-based fallback.

These are the capabilities in this codebase, not a claim that ProMaestro is more mature or more secure than Jira, Asana or Trello. Features such as real-time multi-user collaboration, background automation scheduling, predictive AI, full dependency management and production-grade security should not be presented as implemented unless they are added and tested separately.

## Important verification note
Python syntax compilation has been checked. Full runtime tests could not run in the build environment because Flask is not installed there. Install dependencies using `pip install -r requirements.txt` and run the included tests before relying on this build. This ZIP is an expanded development build, not a claim of production certification.


## Company workspaces and employee accounts

- Company registration creates a company workspace and its first admin account.
- Company Admin Login and Employee Login are available from the sign-in page.
- Company admins/managers can open Employee Management and create employee accounts with a role and initial password.
- User and project records have a `company_id`; existing records are assigned through a non-destructive migration to an `Existing ProMaestro Workspace`.
- Project access checks reject projects outside the signed-in user's company. Reports and company-level queries scope admin access to the authenticated admin's company.
- Employees must be explicitly added to projects through the existing project membership controls.

### Important verification note

Python syntax checks were run for the updated application. Full Flask route/browser tests could not be executed in the current build environment because Flask is not installed and package downloads are unavailable. Run `python -m pip install -r requirements.txt` and then `python -m unittest discover -s tests -v` in the project virtual environment before relying on this build. Company isolation should receive a security review before public production deployment.


## Company login and password reset
- Register a company once. The generated Company ID is the URL-safe company slug; save it and share it only with authorized teammates.
- The company admin/manager creates employee accounts from Employees. Employees cannot self-register.
- Sign in requires Company ID + email + password. Passwords are stored as Werkzeug password hashes, not plain text.
- Forgot password uses signed, expiring (30-minute) reset links. Configure MAIL_SERVER, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD and MAIL_DEFAULT_SENDER for email delivery. For a local demo only, set ALLOW_DEMO_RESET_LINK=true to display the temporary reset link. Do not enable demo links on a public deployment.
- AI Assistant supports local planning guidance without a key; set OPENAI_API_KEY to enable live provider responses. Never commit API keys.
- Database is created as promaestro.db alongside app.py and persists between restarts. Back it up before replacing deployed code.

## Windows quick start
1. Extract the ZIP. Open the inner `ProMaestro_Final` folder (the one containing `app.py` and `requirements.txt`).
2. Run `python -m venv .venv` then `.venv\Scripts\Activate.ps1`.
3. Run `python -m pip install -r requirements.txt` and `python app.py`.
4. Open `http://127.0.0.1:5000`.

## Workspace interaction refresh (October 2026)
- The task board now supports drag-and-drop between workflow columns, with task status saved through the existing permission-checked status route.
- Added live board search across task title, project and assignee; column counts update as the board is filtered.
- Added a show/hide password control on company sign-in and registration forms.
- Added Ctrl+K / Cmd+K to focus the current dashboard/board search when available.
- Refined board controls, drag/drop feedback, login form details and mobile spacing.

To verify locally, install dependencies with `python -m pip install -r requirements.txt`, then run `python -m unittest discover -s tests -v` and `python app.py`.


## Optional Gemini API setup

1. Create a Gemini API key in Google AI Studio. Do not paste it into chat or commit it to source control.
2. Set the environment variable `GEMINI_API_KEY` before starting the app.
3. Optionally set `GEMINI_MODEL` (default: `gemini-2.5-flash`).
4. Install requirements with `pip install -r requirements.txt`.
5. If the key is absent or Gemini fails, the assistant falls back to the existing local rules-based response. Task creation remains a separate manager/admin action.

The Gemini free tier has usage limits and terms that may change; do not enable billing unless you intend to pay.
