"""Smoke and tenant-isolation tests. Run: python -m unittest discover -s tests -v"""
import tempfile
import unittest
from pathlib import Path
import app as app_module
from werkzeug.security import check_password_hash

class ProMaestroSmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        app_module.DB_PATH = Path(self.tmp.name) / 'test.db'
        app_module.app.config.update(TESTING=True, SECRET_KEY='test-secret')
        self.client = app_module.app.test_client()

    def tearDown(self): self.tmp.cleanup()

    def register_company(self, client, company, name, email):
        return client.post('/register', data={'company_name':company,'name':name,'email':email,'password':'password123','confirm_password':'password123'}, follow_redirects=True)

    def test_company_registration_project_and_task_persist(self):
        response=self.register_company(self.client,'Acme Labs','Admin User','admin@acme.test')
        self.assertEqual(response.status_code,200)
        response=self.client.post('/projects/new',data={'name':'Test Project','description':'Smoke test','status':'Planning'},follow_redirects=True)
        self.assertEqual(response.status_code,200)
        with app_module.app.app_context(): project=app_module.get_db().execute('SELECT id FROM projects').fetchone()
        response=self.client.post('/tasks/new',data={'project_id':project['id'],'title':'Test Task','status':'To Do','priority':'High'},follow_redirects=True)
        self.assertEqual(response.status_code,200)
        self.assertIn(b'Test Task',response.data)
        with app_module.app.app_context(): self.assertEqual(app_module.get_db().execute('SELECT COUNT(*) FROM tasks').fetchone()[0],1)

    def test_employee_login_and_cross_company_project_isolation(self):
        self.register_company(self.client,'Company One','Admin One','admin1@example.test')
        self.client.post('/projects/new',data={'name':'Private One','description':'secret','status':'Planning'},follow_redirects=True)
        self.client.post('/employees',data={'name':'Employee One','email':'employee1@example.test','password':'employee123','role':'member'},follow_redirects=True)
        with app_module.app.app_context(): project_id=app_module.get_db().execute('SELECT id FROM projects WHERE name=?',('Private One',)).fetchone()['id']
        other=app_module.app.test_client()
        self.register_company(other,'Company Two','Admin Two','admin2@example.test')
        other.post('/projects/new',data={'name':'Private Two','description':'secret','status':'Planning'},follow_redirects=True)
        denied=other.get(f'/projects/{project_id}',follow_redirects=True)
        self.assertNotIn(b'Private One',denied.data)
        employee=app_module.app.test_client()
        login=employee.post('/login',data={'company_id':'company-one','email':'employee1@example.test','password':'employee123','login_type':'employee'},follow_redirects=True)
        self.assertEqual(login.status_code,200)
        denied=employee.get(f'/projects/{project_id+999}',follow_redirects=True)
        self.assertEqual(denied.status_code,200)


    def test_forgot_password_demo_reset_updates_hash(self):
        import os, re
        os.environ['ALLOW_DEMO_RESET_LINK']='true'
        try:
            self.register_company(self.client,'Reset Labs','Reset User','reset@example.test')
            response=self.client.post('/forgot-password',data={'company_id':'reset-labs','email':'reset@example.test'},follow_redirects=True)
            self.assertEqual(response.status_code,200)
            match=re.search(rb'href="([^"]*/reset-password/[^"]+)"',response.data)
            self.assertIsNotNone(match)
            path=match.group(1).decode()
            response=self.client.post(path,data={'password':'newpassword123','confirm_password':'newpassword123'},follow_redirects=True)
            self.assertEqual(response.status_code,200)
            with app_module.app.app_context():
                user=app_module.get_db().execute('SELECT password_hash FROM users WHERE email=?',('reset@example.test',)).fetchone()
                self.assertTrue(check_password_hash(user['password_hash'],'newpassword123'))
        finally:
            os.environ.pop('ALLOW_DEMO_RESET_LINK',None)

    def test_private_pages_redirect_to_login(self):
        response=self.client.get('/dashboard')
        self.assertEqual(response.status_code,302)

if __name__=='__main__': unittest.main()
