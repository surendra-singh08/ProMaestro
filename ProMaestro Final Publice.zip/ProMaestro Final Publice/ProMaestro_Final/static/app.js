document.addEventListener('submit', function (event) {
  const form = event.target;
  const message = form.getAttribute('data-confirm');
  if (message && !window.confirm(message)) event.preventDefault();
});
document.querySelectorAll('.alert').forEach(function (alert) {
  window.setTimeout(function () { if (alert.classList.contains('show')) { try { bootstrap.Alert.getOrCreateInstance(alert).close(); } catch (_) {} } }, 6500);
});

// Keyboard and accessibility polish for the workspace.
document.addEventListener('keydown', function (event) {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
    const search = document.getElementById('taskQuickSearch') || document.getElementById('boardSearch');
    if (search) { event.preventDefault(); search.focus(); }
  }
});


document.addEventListener('DOMContentLoaded', function () {
  if (document.getElementById('pm-flying-bot')) return;

  const style = document.createElement('style');
  style.textContent = `
    #pm-flying-bot {
      position: fixed; right: 22px; bottom: 24px; z-index: 99999;
      width: 86px; height: 86px; border-radius: 50%;
      border: 3px solid white; background: #5145cd;
      box-shadow: 0 5px 22px #777; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      font-size: 54px; line-height: 1;
      animation: pmFly 2.5s ease-in-out infinite;
    }
    @keyframes pmFly {
      0%, 100% { transform: translateY(0) rotate(-5deg); }
      50% { transform: translateY(-18px) rotate(5deg); }
    }
    #pm-flying-panel {
      position: fixed; right: 22px; bottom: 122px; z-index: 99999;
      display: none; width: 280px; box-sizing: border-box;
      padding: 16px; border-radius: 16px; background: white; color: #222;
      box-shadow: 0 5px 25px #777; font: 14px Arial, sans-serif;
    }
    #pm-flying-panel input { box-sizing: border-box; width: 100%; padding: 10px; }
    #pm-flying-panel button { cursor: pointer; }
  `;
  document.head.appendChild(style);

  const bot = document.createElement('button');
  bot.id = 'pm-flying-bot';
  bot.type = 'button';
  bot.title = 'ProMaestro Assistant';
  bot.setAttribute('aria-label', 'Open ProMaestro Assistant');
  bot.textContent = '\u{1F916}';

  const panel = document.createElement('div');
  panel.id = 'pm-flying-panel';
  panel.innerHTML = '<b>ProMaestro Assistant</b> <button id="pm-fly-close" style="float:right">X</button><p>Hello! Main ProMaestro ka demo assistant hoon.</p><input id="pm-fly-question" placeholder="Apna sawaal likho"><button id="pm-fly-ask" style="margin-top:8px;padding:8px;background:#5145cd;color:white;border:0;border-radius:6px">Ask</button><p id="pm-fly-answer"></p>';

  document.body.appendChild(panel);
  document.body.appendChild(bot);

  bot.addEventListener('click', function () {
    panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
  });
  document.getElementById('pm-fly-close').addEventListener('click', function () {
    panel.style.display = 'none';
  });
  document.getElementById('pm-fly-ask').addEventListener('click', async function () {
    const q = document.getElementById('pm-fly-question').value.trim();
    const a = document.getElementById('pm-fly-answer');
    if (!q) { a.textContent = 'Pehle apna sawaal likho.'; return; }
    a.textContent = 'Jawab taiyar ho raha hai...';
    try {
      const r = await fetch('/ai-assistant', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
        body: new URLSearchParams({prompt: q, mode: 'analysis'})
      });
      const html = await r.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const result = doc.querySelector('pre.ai-result');
      a.textContent = result ? result.innerText.trim() : 'Assistant ka jawab nahi mila. AI Assistant page kholkar check karo.';
    } catch (e) {
      a.textContent = 'Connection error: ProMaestro server chalu hai ya nahi check karo.';
    }
  });
});

/* PM_LOGIN_HELPER_START */
document.addEventListener("DOMContentLoaded", function () {
  if (!["/login", "/register", "/company/register"].includes(location.pathname)) return;
  const input = document.getElementById("pm-fly-question");
  const answer = document.getElementById("pm-fly-answer");
  let ask = document.getElementById("pm-fly-ask");
  if (!input || !answer || !ask) return;
  const cleanAsk = ask.cloneNode(true);
  ask.replaceWith(cleanAsk);
  cleanAsk.addEventListener("click", function () {
    const q = input.value.trim().toLowerCase();
    if (!q) answer.textContent = "Apna login ya registration ka sawaal likho.";
    else if (/forgot|reset|password|पासवर्ड/.test(q)) answer.textContent = "Password bhool gaye ho to login page par Forgot Password option dekho. Agar option nahi hai, administrator se help lo. Apna password kisi ke saath share mat karo.";
    else if (/register|sign.?up|company|रजिस्टर/.test(q)) answer.textContent = "Register ya Company Registration page kholo, form mein maangi gayi details bharo aur submit karo.";
    else if (/employee|manager|admin|role/.test(q)) answer.textContent = "Apne account ke hisaab se Admin, Manager ya Employee login option chuno, agar ye options dikh rahe hon.";
    else if (/login|sign.?in|लॉग.?इन/.test(q)) answer.textContent = "Login page par apni registered email aur password bharo, phir Login button dabao.";
    else answer.textContent = "Main sirf login, password recovery aur registration ke instructions deta hoon. Main projects, tasks ya account data access ya modify nahi karta.";
  });
});
/* PM_LOGIN_HELPER_END */
